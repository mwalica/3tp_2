package variable;

public class Main {
    public static void main(String[] args) {
        System.out.println("Typowanie w Javie");
        int num1;//deklaracja zmiennej lokalnej
        num1 = 23;//inicjalizacja
        int num2, num3, num4;
        num2 = 23;
        num3 = 1;
        num4 = -23;

        int num5 = 234;
        System.out.println(num1);
        //byte 1 bajt 8 bitów
        byte num100 = 127;
        byte num101 = -128;
        System.out.println("byte-min=" + Byte.MIN_VALUE);
        System.out.println("byte-max=" + Byte.MAX_VALUE);
        //short 2 bajty 16 bitów
        short num200 = 12345;
        System.out.println("short-min=" + Short.MIN_VALUE);
        System.out.println("byte-max=" + Short.MAX_VALUE);
        //int 4 bajty 32 bity
        int num300 = 2_147_483_647;
        System.out.println("int-min=" + Integer.MIN_VALUE);
        System.out.println("int-max=" + Integer.MAX_VALUE);
        //long 8 bajtów 64 bity
        long num400 = 21474836499878L;
        System.out.println("long-min=" + Long.MIN_VALUE);
        System.out.println("long-max=" + Long.MAX_VALUE);

        //double
        double num500 = 1.456735354345345344656;
        System.out.println(num500);
        System.out.println("double-min = " + Double.MIN_VALUE);
        System.out.println("double-max = " + Double.MAX_VALUE);
        //float
        float num600 = 1.456735354345345344656F;
        System.out.println(num600);
        System.out.println("float-min = " + Float.MIN_VALUE);
        System.out.println("float-max = " + Float.MAX_VALUE);
        double result = 2.0 - 1.1;
        System.out.println(result);
        double numA = 45;
        System.out.println(numA);

        //char
        char letterA = 'a';
//        String letterA2 = "a";
        char letterCode = 97;
        char letterCode2 = 95;
        System.out.println(letterA);
        System.out.println(letterCode);
        System.out.println(letterCode2);
        //boolean
        boolean isBig = true;
        boolean isSmall = false;

        //final (const) stałe
        final int NUM_C = 123;
//        NUM_C = 235;
        int numD = NUM_C;
        System.out.println(NUM_C);
        System.out.println(numD);
        numD = 457;
        System.out.println(numD);

        //var
        var numF = 20;

    }
}
