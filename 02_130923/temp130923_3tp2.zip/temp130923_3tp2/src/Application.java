import school.*;

import java.util.Random;


public class Application {
    public static void main(String[] args) {

        Teacher.showTeacher();
        Student.showStudent();
        Random random = new Random();

    }
}
