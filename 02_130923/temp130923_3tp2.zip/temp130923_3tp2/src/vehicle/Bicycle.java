package vehicle;

import school.Teacher;

public class Bicycle {
    public static void showBicycle() {
        System.out.println("Jestem rowerem");
        Teacher.showTeacher();
    }
}
