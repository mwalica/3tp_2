package vehicle;

public class Car {
    public static void showCar() {
        System.out.println("Jestem samochodem");
    }
}
