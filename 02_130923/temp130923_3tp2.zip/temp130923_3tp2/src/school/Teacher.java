package school;

public class Teacher {
    public static void showTeacher() {
        System.out.println("Jestem nauczycielem");
        Student.showStudent();
    }
}
