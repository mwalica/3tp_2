package school.s1;

public class Szybin {
}
