package school;

public class Student {
    public static void showStudent() {
        System.out.println("Jestem uczniem");
    }
}
