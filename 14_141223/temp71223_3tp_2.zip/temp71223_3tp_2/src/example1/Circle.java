package example1;

public class Circle extends Shape {

    private int r;

    public Circle(String name, int r) {
        super(name);
        this.r = r;
    }

    @Override
    public double calcArea() {
        return Math.PI * Math.pow(r, 2);
    }
}
