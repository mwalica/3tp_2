package example1;

public class Main {
    public static void main(String[] args) {
//        Shape shape = new Shape("Nieznany kształt");
        Rectangle rectangle1 = new Rectangle(23, 24);
        Rectangle rectangle2 = new Rectangle(5);
        Rectangle rectangle3 = new Rectangle(3, 6, "prostokącik");

//        shape.info();
        rectangle1.info();
        rectangle2.info();
        rectangle3.info();
    }
}
