package example1;

public abstract class Shape {
    protected String name;

    public Shape(String name) {
        this.name = name;
    }

    public void info() {
        System.out.println("Jestem " + name);
    }

    public String getName() {
        return name;
    }

    public abstract double calcArea();
}
