package com.example.temp040424_3tp2_onclicklistener;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnLeft, btnMid, btnRight;
    private TextView tvResult;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLeft = findViewById(R.id.btnLeft);
        btnRight = findViewById(R.id.btnRight);
        btnMid = findViewById(R.id.btnMid);
        tvResult = findViewById(R.id.tvResult);

        btnLeft.setOnClickListener(this);
        btnMid.setOnClickListener(this);
        btnRight.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Button currentBtn = (Button) view;
        if(currentBtn.getText().toString().equals("lewy")) {
            Snackbar.make(view, "To jest lewy button", Snackbar.LENGTH_LONG).show();
        }
        currentBtn.setBackgroundColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
        tvResult.setText(currentBtn.getText());
//        Toast.makeText(this, "Hello", Toast.LENGTH_SHORT).show();
    }

}