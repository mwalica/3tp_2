package com.example.temp180124_np_3tp_2_zadanie;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;

import com.example.temp180124_np_3tp_2_zadanie.model.Car;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView tvSelectedCar, tvResult;
    private Button btnSave;
    private NumberPicker numberPicker;
    private int selectedIndex = 1;
    private List<Car> cars = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSelectedCar = findViewById(R.id.tvSelectedCar);
        tvResult = findViewById(R.id.tvResult);
        btnSave = findViewById(R.id.btnSave);
        numberPicker = findViewById(R.id.numberPicker);

        cars.add(new Car("Fiat", "Panda", 2019));
        cars.add(new Car("Skoda", "Octavia", 2021));
        cars.add(new Car("Opel", "Astra", 2022));

        String[] carsName = new String[cars.size()];
        for(int i = 0; i < carsName.length; i++) {
            carsName[i] = cars.get(i).getCompany();
        }

        numberPicker.setMaxValue(carsName.length - 1);
        numberPicker.setDisplayedValues(carsName);
        numberPicker.setValue(selectedIndex);

        tvSelectedCar.setText(carsName[selectedIndex]);

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int i1) {
                selectedIndex = i1;
                tvSelectedCar.setText(carsName[selectedIndex]);
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvResult.setText(cars.get(selectedIndex).toString());
            }
        });
    }
}