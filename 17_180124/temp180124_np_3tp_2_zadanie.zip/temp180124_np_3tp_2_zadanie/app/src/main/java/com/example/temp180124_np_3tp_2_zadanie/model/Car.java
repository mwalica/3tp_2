package com.example.temp180124_np_3tp_2_zadanie.model;

import androidx.annotation.NonNull;

public class Car {
    private String company;
    private String model;
    private int productionYear;

    public Car(String company, String model, int productionYear) {
        this.company = company;
        this.model = model;
        this.productionYear = productionYear;
    }

    public String getCompany() {
        return company;
    }

    public String getModel() {
        return model;
    }

    public int getProductionYear() {
        return productionYear;
    }

    @NonNull
    @Override
    public String toString() {
        return company + " " + model + ", rok produkcji " + productionYear;
    }
}
