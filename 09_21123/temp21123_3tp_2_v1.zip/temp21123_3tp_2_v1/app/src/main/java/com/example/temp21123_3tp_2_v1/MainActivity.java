package com.example.temp21123_3tp_2_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvTextLeft, tvTextRight;
    private Button btnShowHide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvTextLeft = findViewById(R.id.tvTextLeft);
        tvTextRight = findViewById(R.id.tvTextRight);
        btnShowHide = findViewById(R.id.btnShowHide);

        btnShowHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvTextLeft.getVisibility() == View.VISIBLE) {
                    tvTextLeft.setVisibility(View.INVISIBLE);
                    tvTextRight.setVisibility(View.VISIBLE);
                    btnShowHide.setText("Pokaż z lewej - ukryj z prawej");
                } else {
                    tvTextLeft.setVisibility(View.VISIBLE);
                    tvTextRight.setVisibility(View.INVISIBLE);
                    btnShowHide.setText("Pokaż z prawej - ukryj z lewej");
                }
            }
        });
    }
}