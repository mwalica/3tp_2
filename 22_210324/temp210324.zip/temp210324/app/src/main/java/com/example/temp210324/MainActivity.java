package com.example.temp210324;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.temp210324.model.Person;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private TextView tvResult;
    private Button btnAdd;
    private String name = "";
    //    private String[] names = {"Karolina", "Dagmara", "Zosia"};
    private List<String> names = new ArrayList<>();
    private List<Person> persons = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        tvResult = findViewById(R.id.tvResult);
        btnAdd = findViewById(R.id.btnAdd);

        names.add("Adam");
        names.add("Gustaw");
        names.add("Waldek");

        persons.add(new Person("Grażyna", 43));
        persons.add(new Person("Andrzej", 23));
        persons.add(new Person("Ludmiła", 54));

        //tworzymy adapter
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, names);
        ArrayAdapter<Person> adapter2 = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, persons);
        //podpinamy adapter do spinnera
        spinner.setAdapter(adapter2);
        spinner.setSelection(0);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
//                name = (String) adapterView.getSelectedItem();
                name = persons.get(position).presentation();
                tvResult.setText(name);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btnAdd.setOnClickListener(view -> {
            names.add("Kordian");
            names.add("Szymon");
            adapter1.notifyDataSetChanged();
        });
    }
}