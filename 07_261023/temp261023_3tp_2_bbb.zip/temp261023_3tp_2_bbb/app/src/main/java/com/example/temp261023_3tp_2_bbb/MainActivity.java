package com.example.temp261023_3tp_2_bbb;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private LinearLayout linearLayout;
    private TextView tvText;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //tworzymy referencje
        linearLayout = findViewById(R.id.linearLayout);
        tvText = findViewById(R.id.tvText);

        setMyScreen();

    }

    private void setMyScreen() {
        //        linearLayout.setBackgroundColor(Color.YELLOW);
        //kolor z res colors
        linearLayout.setBackgroundColor(getColor(R.color.purple_700));
        tvText.setText("To jest nowy tekst");
        //kolor z rgb
        tvText.setTextColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
    }
}