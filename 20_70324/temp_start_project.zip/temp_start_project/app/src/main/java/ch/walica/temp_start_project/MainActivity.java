package ch.walica.temp_start_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    public static final String SELECTED = "sel_color";
    private RadioButton rbColor1, rbColor2;
    private String selectedColor = "";

    private Button btnToSecond;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnToSecond = findViewById(R.id.btnToSecond);
        rbColor1 = findViewById(R.id.color1);
        rbColor2 = findViewById(R.id.color2);

        btnToSecond.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            if(rbColor1.isChecked()) {
                selectedColor = "color 1";
            }
            if(rbColor2.isChecked()) {
                selectedColor = "color 2";
            }
            intent.putExtra(SELECTED, selectedColor);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

    }
}