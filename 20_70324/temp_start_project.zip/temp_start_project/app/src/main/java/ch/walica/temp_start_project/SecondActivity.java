package ch.walica.temp_start_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

public class SecondActivity extends AppCompatActivity {

    private Button btnBack;
    private LinearLayout linearLayout;
    private String color = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        btnBack = findViewById(R.id.btnBack);
        linearLayout = findViewById(R.id.linearLayout);

        if(getIntent().hasExtra(MainActivity.SELECTED)) {
            color = getIntent().getStringExtra(MainActivity.SELECTED);
            if(color.equals("color 1")) {
                linearLayout.setBackgroundColor(getColor(R.color.color_1));
            } else {
                linearLayout.setBackgroundColor(getColor(R.color.color_2));
            }
        }

        btnBack.setOnClickListener(view -> {
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        super.onSupportNavigateUp();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        return true;
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}