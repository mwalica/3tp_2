package lesson289823;

public class Example1 {

    public static void main(String[] args) {

        //konwersja niejawna -> duży do małego
        //double -> float -> long -> int -> short -> byte
        double doubleNum = 1.242243243434;
        float floatNum = 3.24224f;
        long longNum = 12423424;
        int intNum = 56756;
        short shortNum = 130;
        byte byteNum = 45;

        double num1 = floatNum;
        long num2 = intNum;
        //konwersja jawna -> mały na duży
        //rzutowanie castowanie => może być utarta danych
        float num3 = (float) doubleNum;//utrata informacje
        int num4 = (int) longNum;
        byte num5 = (byte) shortNum;
        System.out.println(doubleNum + " = " + num3);
        System.out.println(longNum + " = " + num4);
        System.out.println(shortNum + " = " + num5);

    }
}
