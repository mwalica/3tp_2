package lesson289823;

public class Example2 {
    public static void main(String[] args) {
        double doubleNum = 1.242243243434;
        float floatNum = 3.24224f;
        long longNum = 12423424;
        int intNum = 56756;
        short shortNum = 130;
        byte byteNum = 45;

        float result1 = (float) (doubleNum + floatNum);
        float result2 = intNum + floatNum;
        int result3 = byteNum + shortNum;
        int a = 10;
        int b = 20;
        double result4 = (double) a / b;
        System.out.println("1/2 = " + result4);
    }
}
