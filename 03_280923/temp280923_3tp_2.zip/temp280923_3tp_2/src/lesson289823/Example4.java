package lesson289823;

public class Example4 {

    public static void main(String[] args) {
        int numA = 45;
        int numB = 45;

        String name1 = "Jan";
        String emptyStr = "";
        String name3 = null;
        emptyStr = null;
        String name2 = new String("Karol");
        emptyStr = name2;

        //porównywanie typów prostych
        System.out.println("numA == numB: " + (numA == numB));

        //porównywanie typów klasowych == sprawdza referencje (czy ta sama referencja)
        String car1 = "Audi";
        String car2 = "Audi";
        String car3 = new String("Audi");
        String car4 = car3;
        car3 = "Ford";
        String car5 = "AUDI";

        System.out.println("car1 == car2: " + (car1 == car2));
        System.out.println("car1 == car3: " + (car1 == car3));
        System.out.println("car3 == car4: " + (car3 == car4));
        System.out.println("car1 == car4: " + (car1 == car4));

        //porównywanie wartości typów klasowych odbywa się przy pomocy metody equals
        System.out.println("car1 equals car2: " + car1.equals(car2));
        System.out.println("car1 equals car3: " + car1.equals(car3));
        System.out.println("car3 equals car4: " + car3.equals(car4));
        System.out.println("car1 equals car4: " + car1.equals(car4));
        System.out.println("car1 equals car4: " + car1.equalsIgnoreCase(car5));




    }
}
