package lesson289823;

public class Example5 {

    public static void main(String[] args) {
        String name1 = "Kasia";
        System.out.println(name1);
        String name2 = name1;
        name1 = "Barbara";
        System.out.println(name1);
        System.out.println(name2);

        //konkatenacja
        int age = 23;
        String firstName = "Jan";
        String lastName = "Kowal";
        System.out.println(firstName + " " + lastName + " ma lat " + age);
        System.out.println("" + age + 6 + " " + firstName + " " + lastName);
        System.out.println("" + age + 6 + " " + firstName + " " + lastName + 20 + 7);
        System.out.println("" + age + 6 + " " + firstName + " " + lastName + " " +(20 + 7));
        System.out.println(firstName.concat(" ").concat(lastName).concat(" ma lat ").concat("" + age));

    }
}
