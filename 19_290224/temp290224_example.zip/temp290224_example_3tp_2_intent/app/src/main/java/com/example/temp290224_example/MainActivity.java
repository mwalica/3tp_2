package com.example.temp290224_example;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.temp290224_example.model.User;

public class MainActivity extends AppCompatActivity {

    public static final String NAME_KEY = "key_name";
    public static final String AGE_KEY = "key_age";
    public static final String USER_KEY = "user_obj";

    private Button btnSend;
    private EditText etName, etAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSend = findViewById(R.id.btnSend);
        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etName.getText().toString().trim();
                String age = etAge.getText().toString().trim();
                if(!name.isEmpty() && !age.isEmpty()) {
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
//                    intent.putExtra(NAME_KEY, name);
//                    intent.putExtra(AGE_KEY, Integer.parseInt(age));
                    User user = new User(name, Integer.parseInt(age));
                    intent.putExtra(USER_KEY, user);
                    startActivity(intent);
                    //animacja                        wejście                wyjście
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else {
                    Toast.makeText(MainActivity.this, "Proszę wypełnić formularz", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }
}