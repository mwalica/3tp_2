package com.example.temp110424aaa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button view1, view2;
    private Button btnSave, btnCompare;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        view1 = findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);
        btnSave = findViewById(R.id.btnSave);
        btnCompare = findViewById(R.id.btnCompare);

//        view1.setBackgroundColor(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
        view1.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256))));

        btnSave.setOnClickListener(view -> {
//            Drawable background = view1.getBackground();
            int background = view1.getBackgroundTintList().getColorForState(new int[]{android.R.attr.state_enabled}, 0);
            view2.setBackgroundTintList(ColorStateList.valueOf(background));

        });

        btnCompare.setOnClickListener(view -> {
            Drawable background1 = view1.getBackground();
            Drawable background2 = view2.getBackground();
            if(background1 == background2) {
                Toast.makeText(this, "Te same kolory", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Różne kolory", Toast.LENGTH_SHORT).show();
            }
        });
    }
}