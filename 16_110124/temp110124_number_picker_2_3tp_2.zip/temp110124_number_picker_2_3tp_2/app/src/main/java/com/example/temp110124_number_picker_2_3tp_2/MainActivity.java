package com.example.temp110124_number_picker_2_3tp_2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.NumberPicker;
import android.widget.TextView;

import com.example.temp110124_number_picker_2_3tp_2.model.Person;

public class MainActivity extends AppCompatActivity {

    private NumberPicker numberPicker;
    private TextView tvResult;
    private Person[] persons = {
            new Person("Jan", Color.RED),
            new Person("Karolina", Color.BLUE),
            new Person("Ania", Color.YELLOW),
    };
    private int currentIndex = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numberPicker = findViewById(R.id.numberPicker);
        tvResult = findViewById(R.id.tvResult);

        String[] names = new String[persons.length];
        for(int i = 0; i < names.length; i++) {
            names[i] = persons[i].getName();
        }

        numberPicker.setMaxValue(names.length - 1);
        numberPicker.setValue(currentIndex);
        numberPicker.setDisplayedValues(names);
        tvResult.setText(names[currentIndex]);

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int newVal) {
                currentIndex = newVal;
                tvResult.setText(persons[currentIndex].getName());
                tvResult.setTextColor(persons[currentIndex].getColor());
            }
        });


    }
}