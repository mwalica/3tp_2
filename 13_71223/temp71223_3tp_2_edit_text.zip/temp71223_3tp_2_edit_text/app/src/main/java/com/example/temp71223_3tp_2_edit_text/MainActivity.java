package com.example.temp71223_3tp_2_edit_text;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etEnteredText;
    private Button btnShow;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEnteredText = findViewById(R.id.etEnteredText);
        btnShow = findViewById(R.id.btnShow);
        tvResult = findViewById(R.id.tvResult);

        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String enteredText = etEnteredText.getText().toString().trim();
                if(!enteredText.isEmpty()) {
                    tvResult.setText(enteredText.toUpperCase());
                    etEnteredText.getText().clear();
                } else {
                    Toast.makeText(MainActivity.this, "Proszę wpisać tekst", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}