package array_1;

import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //tablica z 10 elementami
        int[] nums = new int[10];
        String[] cars = new String[3];
        boolean bool[] = new boolean[5];

        nums[0] = 34;
        for(int i = 0; i < nums.length; i++) {
            nums[i] = new Random().nextInt(101);
        }

        cars[0] = "Fiat";
        cars[2] = "Ford";
        cars[1] = "Skoda";
        cars[0] = "BMW";

        System.out.println(Arrays.toString(nums));
        System.out.println(Arrays.toString(cars));
        System.out.println(Arrays.toString(bool));
        System.out.println("======");
        String[] names = {"Jan", "Konrad", "Gustaw", "Anna", "Iza"};
        System.out.println(Arrays.toString(names));
        String[] names2 = names;
        String[] names3 = names.clone();
        names2[0] = "Karolina";
        names3[2] = "Adam";
        String[] names4 = Arrays.copyOf(names, 10);
        String[] names5 = Arrays.copyOfRange(names, 1,3);


        System.out.println(Arrays.toString(names));
        System.out.println(Arrays.toString(names2));
        System.out.println(Arrays.toString(names3));
        System.out.println(Arrays.toString(names4));
        System.out.println(Arrays.toString(names5));


        for(int i = 0; i < names.length; i++) {
            System.out.println(names[i]);
        }
        for(String name : names) {
            System.out.println(name);
        }
    }
}
