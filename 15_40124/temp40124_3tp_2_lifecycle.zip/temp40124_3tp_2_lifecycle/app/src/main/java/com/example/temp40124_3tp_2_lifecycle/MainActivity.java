package com.example.temp40124_3tp_2_lifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("my_log", "onCreate loaded");

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("my_log", "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("my_log", "onResume");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("my_log", "onRestart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("my_log", "onPause: ");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("my_log", "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("my_log", "onDestroy");
    }
}