package com.example.temp40123_3tp_2_numberpicker_saveinstantstate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.NumberPicker;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private NumberPicker numberPicker;
    private TextView tvResult;
    private int counter = 50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numberPicker = findViewById(R.id.numberPicker);
        tvResult = findViewById(R.id.tvResult);

        if(savedInstanceState != null) {
            counter = savedInstanceState.getInt("counter_key");
        }

        numberPicker.setMaxValue(100);
        numberPicker.setValue(counter);

        tvResult.setText(String.valueOf(counter));

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int oldVal, int newVal) {
                counter = newVal;
                tvResult.setText(String.valueOf(counter));
            }
        });

    }


    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("counter_key", counter);
    }
}